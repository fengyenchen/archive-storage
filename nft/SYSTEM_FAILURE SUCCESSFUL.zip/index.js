let cs;
let balls = [];
let colorLists = [
    "3d5a80-98c1d9-e0fbfc-ee6c4d-293241".split("-").map(a => "#" + a),
    "011627-f71735-41ead4-fdfffc-ff9f1c".split("-").map(a => "#" + a),
    "2b2d42-8d99ae-f8f32b-ffffff-000000".split("-").map(a => "#" + a),
    "222222-ffffff-4b4e6d-84dcc6-95a3b3".split("-").map(a => "#" + a),
    "114b5f-456990-e4fde1-f45b69-6b2737".split("-").map(a => "#" + a),
    "84dcc6-d6edff-acd7ec-8b95c9-478978".split("-").map(a => "#" + a),
    "17bebb-2e282a-cd5334-edb88b-fad8d6".split("-").map(a => "#" + a),
    "8693ab-bdd4e7-212227-637074-aab9cf".split("-").map(a => "#" + a),
    "111-333-555-777-999-bbb-ddd-fff".split("-").map(a => "#" + a),
    "ff0055-00fbff-7000ff-ffea00-333333".split("-").map(a => "#" + a),
    "ff2a6d-05d9e8-005677-ff2a6d-d1feff".split("-").map(a => "#" + a),
    "9a8c98-f2e9e4-4a4e69-22223b-c9ada7".split("-").map(a => "#" + a),
    "e63946-f1faee-a8dadc-457b9d-1d3557".split("-").map(a => "#" + a),
    "03045e-023e8a-0077b6-00b4d8-caf0f8".split("-").map(a => "#" + a),
    "ff4d00-ff8800-444444-222222-ff0000".split("-").map(a => "#" + a),
    "4d1c1c-2f3d39-1a1c1c-5e4d2a-2d333b".split("-").map(a => "#" + a),
    "d6e2e9-bcd4e6-99c1de-6497b1-013a63".split("-").map(a => "#" + a),
    "ccff00-101820-cfdf4a-222222-99ff00".split("-").map(a => "#" + a),
    "ff0000-ffcc00-0000ff-ffffff-000000".split("-").map(a => "#" + a),
    "e29578-83c5be-edf6f9-ffddd2-006d77".split("-").map(a => "#" + a),
    "240046-3c096c-5a189a-7b2cbf-9d4edd-ff9100".split("-").map(a => "#" + a),
    "d4af37-1a1a1b-333333-f1f1f1-c0c0c0".split("-").map(a => "#" + a),
    "264653-2a9d8f-e9c46a-f4a261-e76f51".split("-").map(a => "#" + a),
    "0d1b2a-1b263b-415a77-778da9-1b263b".split("-").map(a => "#" + a)
];
let colorList;

class BuggyBall {
    constructor(p, r) {
        this.p = p;
        this.v = createVector(1, 0).rotate(random(PI * 4)).mult(random(cs * 0.005, cs * 0.012));
        this.a = createVector(1, 0).rotate(random(PI * 4)).mult(cs * 0.0002);
        this.r = r;
        this.color = random(colorList);
        let c = color(this.color);
        c.setAlpha(random(150, 255));
        this.color = c;
        this.rotateFactor = random() < 0.08 ? 80 : random(-0.3, 0.3);
    }

    update() {
        this.p.add(this.v);
        this.v.add(this.a);
        this.r *= 0.98;
        if (this.r < cs / 300 && random() < 0.1) {
            this.r = random(cs / 12, cs / 6);
        }
        this.v.rotate(this.rotateFactor);
    }

    draw() {
        if (this.r < cs / 12 && this.r > cs / 100) {
            let fc = color(this.color);
            fc.setAlpha(map(this.r, cs / 100, cs / 12, 255, 130));
            fill(fc);
            noStroke();
        } else {
            let sc = color(this.color);
            sc.setAlpha(map(this.r, cs / 1, cs / 12, 255, 160));
            stroke(sc);
            if (this.r < cs / 100) {
                stroke(150);
            }
            strokeWeight(cs * 0.0012);
            noFill();
        }

        if (random() < 0.008) {
            strokeWeight(cs * 0.0012);
            stroke(this.color);
            line(this.p.x, this.p.y, width, this.p.y);
        } else {
            circle(this.p.x, this.p.y, this.r);
            if (random() < 0.08) {
                stroke(255, 160);
                strokeWeight(cs * 0.0016);
                circle(this.p.x, this.p.y, this.r * 1.02);
            }
        }
    }
}

function setup() {
    cs = min(windowHeight, windowWidth);
    createCanvas(cs, cs);
    noLoop();
    setSeeds();
}

function draw() {
    background(15);

    drawBuggyBalls(0, 0, 1);

    // 掃描線
    strokeWeight(cs * 0.002);
    for (let i = 0; i < height; i += cs / 200) {
        let alpha = map(abs(height / 2 - i), 0, height / 2, 80, 20);
        stroke(250, alpha);
        line(0, i, width, i);
    }

    drawVertexFrame(0, cs * 0.025, 235, 100, 180, 140);
    if (random() < 0.5) {
        drawVertexFrame(cs * 0.025, cs * 0.02, 200, 80, 140, 125);
    }
    if (random() < 0.2) {
        drawVertexFrame(cs * 0.3, cs * 0.03, 183, 70, 120, 118);
    }

    loadPixels();
    for (let i = 0; i < pixels.length; i += 28) {
        let g = random(-20, 20);
        pixels[i] += g;
        pixels[i + 1] += g;
        pixels[i + 2] += g;
    }
    updatePixels();

    triggerPreview();
}

function drawBuggyBalls(x = 0, y = 0, ratio = 1) {
    push();
    translate(x, y);
    scale(ratio);

    colorList = colorLists[(int(random(colorLists.length)) + int((1 - ratio) * colorLists.length)) % colorLists.length];

    for (let i = 0; i < 2 * PI; i += PI / 24) {
        let rr = random(cs / 2.2, cs / 1.8);
        balls.push(new BuggyBall(createVector(width / 2 + rr * cos(i), height / 2 + rr * sin(i)), random(cs / 20, cs / 2)));
    }
    for (let i = 0; i < 8; i++) {
        balls.push(new BuggyBall(createVector(width / 2, height / 2), random(cs / 8, cs / 1.8)));
    }

    for (let t = 0; t < 300; t++) {
        for (let i = balls.length - 1; i >= 0; i--) {
            balls[i].update();
            balls[i].draw();
            if (balls[i].r < cs / 500 ||
                balls[i].p.x > width || balls[i].p.x < 0 ||
                balls[i].p.y > height || balls[i].p.y < 0) {
                balls.splice(i, 1);
            }
            if (t % 5 == 0 && balls.length < 60) {
                balls.push(new BuggyBall(createVector(random(width), random(height)), random(cs / 120, cs / 30)));
            }
        }
    }
    balls = [];

    pop();
}

function drawVertexFrame(p, b, cT, cB, cL, cR) {
    noStroke();
    fill(cT);
    beginShape(); 
    vertex(p, p); vertex(width - p, p); 
    vertex(width - b - p, b + p); 
    vertex(b + p, b + p); 
    endShape(CLOSE);
    fill(cB);
    beginShape(); 
    vertex(p, height - p); 
    vertex(width - p, height - p); 
    vertex(width - b - p, height - b - p); 
    vertex(b + p, height - b - p); 
    endShape(CLOSE);
    fill(cL);
    beginShape(); 
    vertex(p, p); 
    vertex(b + p, b + p); 
    vertex(b + p, height - b - p); 
    vertex(p, height - p); 
    endShape(CLOSE);
    fill(cR);
    beginShape(); 
    vertex(width - p, p); 
    vertex(width - b - p, b + p); 
    vertex(width - b - p, height - b - p); 
    vertex(width - p, height - p); 
    endShape(CLOSE);
}

function keyPressed() {
    if (key == 's' || key == 'S') {
        save("SYSTEM_FAILURE_SUCCESSFUL.png");
    }
}

function windowResized() {
    setSeeds();
    cs = min(windowHeight, windowWidth);
    resizeCanvas(cs, cs);
    redraw();
}