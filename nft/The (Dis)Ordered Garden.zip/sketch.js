
let targetCanvasWidth = 1000;
let targetCanvasHeight = 1000;
let deviceRatio = 1;

function SetupCanvasScale() {
	let originalDensity = pixelDensity();

	if (windowWidth > targetCanvasWidth) {
		deviceRatio = (windowWidth / targetCanvasWidth);
	} else {
		deviceRatio = originalDensity;
	}

	deviceRatio = max(deviceRatio, 1);
	pixelDensity(deviceRatio);
}

let frameSizes = [];

let colorStamens = ['#EDD445', '#EDC945', '#EDBD45'];
let colorStamensDecorate = ['#FD9445', '#FDE945', '#ED8345'];
let colorPetal = ['#FFFFFF', '#F8F8F8', '#F4F4F4'];
let colorLeaves = ['rgba(100,200,100,0.7)', 'rgba(80,180,80,0.6)', 'rgba(120,220,120,0.8)'];
let flowerGraphic;
let texture;

function preload() {
	texture = loadImage("4.jpg");
}

async function setup() {
	createCanvas(targetCanvasWidth, targetCanvasHeight);
	SetupCanvasScale();
	flex();

	background(244, 229, 213);

	flowerGraphic = createGraphics(width, height);

	flowerGraphic.drawingContext.shadowColor = color(0, 50);
	flowerGraphic.drawingContext.shadowBlur = 8;
	flowerGraphic.drawingContext.shadowOffsetX = 4;
	flowerGraphic.drawingContext.shadowOffsetY = 4;

	generateFrame();
	noLoop();
}

function draw() {
	background(244, 229, 213);

	noFill();
	stroke(204, 167, 143, 13);
	for (let i = 0; i < 10; i++) {
		strokeWeight(frameSizes[0][i]);
		rect(-200, 0, 1400, 900);
	}

	let gridSize = 20;
	let start = (width - gridSize * 46) / 2;

	drawGarden(flowerGraphic, gridSize, start);
	image(flowerGraphic, 0, 0, width, height);

	noFill();
	stroke(3, 3);
	for (let i = 0; i < 20; i++) {
		strokeWeight(frameSizes[3][i]);
		rect(40, 40, 920, 920);
	}

	drawOuterFrame();

	push();
	blendMode(MULTIPLY);
	tint(255, 150);
	image(texture, 0, 0, width, height);
	pop();
}


function drawGarden(graphic, gridSize, start) {
	graphic.fill(5, 180);
	graphic.noStroke();
	graphic.rect(0, 0, width, height);

	for (let i = start; i < (width - start); i += gridSize) {
		for (let j = start; j < (height - start); j += gridSize) {
			graphic.push();
			graphic.translate(i + gridSize / 2, j + gridSize / 2);

			let flowerSize = random(gridSize, gridSize * 2.8);

			if (random() < 0.5) {
				drawFlowerLeaves(graphic, flowerSize);
			}
			if (random() < 0.25) {
				drawFlowerPetal(graphic, flowerSize);
			}
			if (random() < 0.6) {
				drawFlowerStamen(graphic, flowerSize);
			}
			if (random() < 0.45) {
				drawFlowerSmall(graphic, flowerSize);
			}
			if (random() < 0.55) {
				drawFlowerDecorLine(graphic, flowerSize);
			}
			if (random() < 0.6) {
				drawDotsAndSquares(graphic, flowerSize);
			}
			graphic.pop();
		}
	}
}

function drawFlowerPetal(graphic, s) {
	graphic.push();
	let petals = floor(random(5, 8));
	for (let i = 0; i < petals; i++) {
		graphic.fill(random(colorPetal));
		graphic.strokeWeight(1);
		graphic.stroke(220);
		graphic.bezier(0, 0, -30, s, 30, s, 0, 0);
		graphic.stroke(225);
		graphic.line(3, -3, 5, s / 2);
		graphic.line(-3, 3, -4, s / 3);
		graphic.rotate(random(PI / 4, PI / 2));
	}
	graphic.pop();
}

function drawFlowerStamen(graphic, s) {
	graphic.push();
	graphic.noStroke();
	graphic.fill(random(colorStamens));
	graphic.ellipse(0, 0, s * 0.35, s * 0.35);

	graphic.fill(random(colorStamensDecorate));
	for (let i = 0; i < floor(random(1, 5)); i++) {
		graphic.ellipse(random(-s * 0.15, s * 0.15), random(-s * 0.15, s * 0.15), random(2, 5), random(2, 5));
	}
	graphic.pop();
}

function drawFlowerSmall(graphic, s) {
	graphic.push();
	let num = floor(random(2, 6));
	for (let i = 0; i < num; i++) {
		graphic.fill(random(colorPetal));
		graphic.noStroke();
		let dx = random(-s * 0.4, s * 0.4);
		let dy = random(-s * 0.4, s * 0.4);
		let w = random(s * 0.2, s * 0.35);
		let h = random(s * 0.1, s * 0.25);
		graphic.ellipse(dx, dy, w, h);
	}
	graphic.pop();
}

function drawFlowerDecorLine(graphic, s) {
	graphic.stroke(180);
	graphic.strokeWeight(1);
	for (let i = 0; i < floor(random(1, 5)); i++) {
		graphic.line(random(-s * 0.1, s * 0.1), random(-s * 0.1, s * 0.1),
			random(-s * 0.1, s * 0.1), random(-s * 0.1, s * 0.1));
	}
}

function drawFlowerLeaves(graphic, s) {
	graphic.push();
	let numLeaves = floor(random(2, 6));
	for (let i = 0; i < numLeaves; i++) {
		graphic.rotate(random(PI * 2));
		graphic.fill(random(colorLeaves));
		graphic.noStroke();
		let w = random(s * 0.2, s * 0.5);
		let h = random(s * 0.05, s * 0.15);
		graphic.ellipse(s * 0.4, 0, w, h);
	}
	graphic.pop();
}

function drawDotsAndSquares(graphic, s) {
	let numDots = floor(random(4));
	for (let i = 0; i < numDots; i++) {
		let x = random(-s * 0.5, s * 0.5);
		let y = random(-s * 0.5, s * 0.5);
		if (random() < 0.5) {
			graphic.fill(random(colorStamensDecorate));
			graphic.noStroke();
			graphic.rectMode(CENTER);
			graphic.rect(x, y, random(2, 5), random(2, 5));
		}
	}
}

function drawOuterFrame() {
	noFill();
	stroke(247, 235, 225);
	strokeWeight(86);
	rectMode(CENTER);
	rect(width / 2, height / 2, 1000, 1000);

	noFill();
	stroke(204, 167, 143, 7);
	rectMode(CORNER);
	for (let i = 0; i < 10; i++) {
		strokeWeight(float(frameSizes[1][i]));
		rect(-10, 0, 1020, 1000);
	}

	stroke(3, 50);
	for (let i = 0; i < 40; i++) {
		strokeWeight(frameSizes[2][i]);
		rect(0, 0, 1000, 1000);
	}
}

function generateFrame() {
	frameSizes = [
		[],
		[],
		[],
		[]
	];
	for (let i = 0; i < 10; i++) {
		frameSizes[0][i] = random(300);
	}
	for (let i = 0; i < 10; i++) {
		frameSizes[1][i] = random(100);
	}
	for (let i = 0; i < 40; i++) {
		frameSizes[2][i] = random(35);
	}
	for (let i = 0; i < 20; i++) {
		frameSizes[3][i] = random(5, 12);
	}
}

function keyPressed() {
	if (key === 's' || key === 'S') {
		saveCanvas("The_(Dis)Ordered_Garden.png");
	}
}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}