let cs;

let colorLists = [
	["#264653", "#2a9d8f", "#e9c46a", "#f4a261", "#e76f51", "#d62828", "#023047"],
	["#ae2012", "#720017", "#e8d3ba", "#d64f44", "#3d0e0b", "#c88478", "#f4f4f4"],
	["#0f2540", "#194482", "#5279b3", "#a2d8d8", "#112a45", "#f0ebe5", "#8a9bac"],
	["#b4a078", "#d9a05b", "#8c6931", "#563624", "#e9d7a3", "#2c2c2c", "#fdfcf5"],
	["#1a1c2c", "#4a4e69", "#9ad1d4", "#808b96", "#2d3436", "#dfe6e9", "#b2bec3"],
	["#2d6a4f", "#1b4332", "#40916c", "#74c69d", "#95d5b2", "#d8f3dc", "#081c15"],
	["#606c38", "#283618", "#a3b18a", "#dad7cd", "#344e41", "#588157", "#fefae0"],
	["#2a9d8f", "#264653", "#1d3557", "#457b9d", "#8ab17d", "#e9c46a", "#f1faee"],
];

let colors;
let mode;

function setup() {
    cs = min(windowHeight, windowWidth);
    createCanvas(cs, cs);
    noLoop();
    setSeeds();
}

function draw() {
    colors = random(colorLists);
    background("#f1f1e6");

    let margin = width / 25;
    let layer = int(random(6, 12));

    mode = int(random(3)); // 直 方 橫
    drawRecursiveGrid(margin, margin, width - margin * 2, height - margin * 2, layer);

    loadPixels();
    for (let i = 0; i < pixels.length; i += 4) {
        let grain = random(-30, 30);
        pixels[i] += grain;
        pixels[i + 1] += grain;
        pixels[i + 2] += grain;
    }
    updatePixels();
  
    triggerPreview();
}

function drawRecursiveGrid(x, y, w, h, layer) {
    let padding = 0;

    if (layer <= 0 || (w < width / 8 && random() < 0.4)) {
        drawPattern(x + padding / 2, y + padding / 2, w - padding, h - padding);
        return;
    }

    let splitRatio = random(0.2, 0.8);
    
    let condition;
    if (mode === 0) {
        condition = random() < 0.9;
    } else if (mode === 1) {
        condition = w > h * 1.2;
    } else if (mode === 2) {
        condition = random() < 0.1;
    }
  
    if (condition) {
        drawRecursiveGrid(x, y, w * splitRatio, h, layer - 1);
        drawRecursiveGrid(x + w * splitRatio, y, w * (1 - splitRatio), h, layer - 1);
    } else {
        drawRecursiveGrid(x, y, w, h * splitRatio, layer - 1);
        drawRecursiveGrid(x, y + h * splitRatio, w, h * (1 - splitRatio), layer - 1);
    }
}

function drawPattern(x, y, w, h) {
    push();
    translate(x, y);

    let mainColor = color(random(colors));
    
    // 格底
    fill(mainColor);
    noStroke();
    rect(0, 0, w, h); 

    // 遮罩
    drawingContext.beginPath();
    drawingContext.rect(0, 0, w, h);
    drawingContext.clip();

    // 根據面積計算裝飾密度
    let area = w * h;
    let fillingDensity = map(area, 0, width * height / 10, 0.4, 1.0, true);

    // 根據底色亮度調整線條顏色
    let brightnessVal = brightness(mainColor);
    if (brightnessVal > 92) {
        stroke(100, 180);
    } else {
        stroke(255, 210);
    }
    
    noFill();
    strokeWeight(width / 350); 

    let patternType = int(random(8));
    patterns(w, h, fillingDensity, patternType);

    pop();
}

function patterns(w, h, fillingDensity, patternType) {
    if (patternType === 0) {
        // 放射狀線條
        let step = map(fillingDensity, 0.4, 1, 15, 8);
        let centerX = w / 2;
        let centerY = h;
        for (let i = 0; i <= 180; i += step) {
            line(centerX, centerY, centerX + cos(radians(i + 180)) * max(w, h) * 2, centerY + sin(radians(i + 180)) * max(w, h) * 2);
        }
    } else if (patternType === 1) {
        // 雙波源干涉
        let waveStep = map(fillingDensity, 0.4, 1, width / 15, width / 35);
        for (let r = 0; r < max(w, h) * 2.5; r += waveStep) {
            arc(w * 0.3, h, r, r, PI, TWO_PI);
            arc(w * 0.7, h, r, r, PI, TWO_PI);
        }
    } else if (patternType === 2) {
        // 斜線
        let spacing = map(fillingDensity, 0.4, 1, width / 50, width / 120);
        for (let i = -h; i < w + h; i += spacing) {
            line(i, 0, i + h, h);
        }
    } else if (patternType === 3) {
        // 同心圓
        let count = int(map(fillingDensity, 0.4, 1, 4, 10));
        for (let i = count; i > 0; i--) {
            fill(255, 20 * pow(fillingDensity, 0.6));
            ellipse(w / 2, h / 2, (max(w, h) / count) * i);
        }
    } else if (patternType === 4) {
        // 干涉點陣
        noStroke();
        fill(255, 190);
        let res = map(fillingDensity, 0.4, 1, width / 80, width / 150);
        for (let i = 0; i < w; i += res) {
            for (let j = 0; j < h; j += res) {
                let d1 = dist(i, j, w * 0.3, h * 0.5);
                let d2 = dist(i, j, w * 0.7, h * 0.5);
                if (sin(d1 * 0.15 - d2 * 0.15) > 0.4) {
                    ellipse(i, j, width / 300, width / 300);
                }
            }
        }
    } else if (patternType === 5) {
        // 隨機點陣
        let space = width / 60;
        noStroke();
        fill(255, 180);
        for (let ix = space / 2; ix < w; ix += space) {
            for (let iy = space / 2; iy < h; iy += space) {
                if (random() < fillingDensity) {
                    ellipse(ix, iy, width / 250, width / 250);
                }
            }
        }
    } else if (patternType === 6) {
        // 迷宮
        strokeWeight(width / 400);
        let sz = map(fillingDensity, 0.4, 1, width / 35, width / 55);
        for (let ix = 0; ix < w; ix += sz) {
            for (let iy = 0; iy < h; iy += sz) {
                if (random() < fillingDensity) {
                    if (random() > 0.5) {
                        line(ix, iy, ix + sz, iy + sz);
                    } else {
                        line(ix + sz, iy, ix, iy + sz);
                    }
                }
            }
        }
    } else if (patternType === 7) {
        // 垂直線
        let spacing = map(fillingDensity, 0.4, 1, width / 60, width / 150);
        for (let i = 0; i < w; i += spacing) {
            if (random() < fillingDensity) {
                line(i, 0, i, h);
            }
        }
    }
}

function keyPressed() {
    if (key == "s" || key == "S") {
        save("The Rhythm of Ink Grids.png");
    }
}

function windowResized() {
    setSeeds();
    cs = min(windowHeight, windowWidth);
    resizeCanvas(cs, cs);
}