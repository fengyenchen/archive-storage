
let targetCanvasWidth = 1000;
let targetCanvasHeight = 1000;
let deviceRatio = 1;

function SetupCanvasScale() {
	let originalDensity = pixelDensity();

	if (windowWidth > targetCanvasWidth) {
		deviceRatio = (windowWidth / targetCanvasWidth);
	} else {
		deviceRatio = originalDensity;
	}

	deviceRatio = max(deviceRatio, 1);
	pixelDensity(deviceRatio);
}

let paused = false;

async function setup() {
	createCanvas(targetCanvasWidth, targetCanvasHeight);
	SetupCanvasScale();
	flex();

	background(20);
	frameRate(1);

	generateFrame();
	// noLoop();
}

function draw() {
	background(random(20, 40));

	// 內部框
	for (let i = 0; i < 10; i++) {
		stroke(35, 2);
		strokeWeight(random(150));
		rectMode(CENTER);
		rect(width / 2, height / 2, width - 200, height - 200);
	}

	let gridSize = 36;
	let startPos = (width - gridSize * 25) / 2 + gridSize;
	let endPos = width - (width - gridSize * 25) / 2 - gridSize;

	draweMysticScore(gridSize, startPos, endPos);

	// 外框
	let frameColor;
	if (0 == 252 || 0 == 255) {

		frameColor = color(249, 250, 247);
	} else {

		frameColor = color(45, 40, 45);
	}

	stroke(frameColor);
	strokeWeight(200);
	noFill();
	rectMode(CORNER);
	rect(0, 0, width, height);

	// 邊框紋路
	for (let i = 0; i < 10; i++) {
		stroke(234, 234, 234, 8);
		strokeWeight(random(200));
		rect(0, 0, width, height);
	}

	// 邊界陰影
	noStroke();

	// 頂部
	fill(80, 90);
	beginShape();
	vertex(100, 100);
	vertex(900, 100);
	vertex(905, 95);
	vertex(95, 95);
	endShape(CLOSE);

	// 右側
	fill(255 - 0, 100);
	beginShape();
	vertex(900, 100);
	vertex(900, 900);
	vertex(905, 905);
	vertex(905, 95);
	endShape(CLOSE);

	// 底部
	fill(255, 200);
	beginShape();
	vertex(100, 900);
	vertex(900, 900);
	vertex(905, 905);
	vertex(95, 905);
	endShape(CLOSE);

	for (let k = 0; k < 15; k++) {
		stroke(255);
		strokeWeight(random());
		noFill();
		let frameLineSize1 = random(width - 75, width - 20);
		rectMode(CENTER);
		rect(width / 2, height / 2, frameLineSize1, frameLineSize1);
		let frameLineSize2 = random(width - 105, width - 145);
		rect(width / 2, height / 2, frameLineSize2, frameLineSize2);
	}
}


function draweMysticScore(gridSize, startPos, endPos) {

	let baseColors = [color(109, 148, 197), color(203, 220, 235)];
	let patternColors = [color(112, 137, 147), color(161, 194, 189)];
	let symbolColors = [color(220, 20, 60), color(255, 188, 76)];

	background(random(20, 40));
	for (let i = startPos; i < endPos; i += gridSize) {
		for (let j = startPos; j < endPos; j += gridSize) {
			push();
			translate(i, j);
			rectMode(CORNER);
			stroke(150, 60);
			strokeWeight(1);
			noFill();
			rect(0, 0, gridSize, gridSize);

			let baseColor = random(baseColors);
			let patternColor = random(patternColors);
			let symbolColor = random(symbolColors);

			// 基礎圖案
			stroke(baseColor);
			strokeWeight(1);
			noFill();
			for (let t = 0; t < 2; t++) {
				let x1 = gridSize / 32 + t * gridSize / 16;
				let x2 = gridSize - gridSize / 32 - t * gridSize / 16;
				let y = gridSize / 2;
				ellipse(x1, y, gridSize / 4, gridSize / 4);
				ellipse(x2, y, gridSize / 4, gridSize / 4);
			}
			fill(baseColor);
			ellipse(gridSize / 2, gridSize / 4, gridSize / random(4, 16), gridSize / random(4, 16));
			ellipse(gridSize / 2, gridSize * 3 / 4, gridSize / random(5, 7), gridSize / random(5, 7));

			// 弧線 / 線條 / 曲線
			let type = floor(random(11));
			stroke(patternColor);
			strokeWeight(1);
			noFill();
			for (let t = 0; t < 3; t++) {
				let offset = t * gridSize / 16;
				switch (type) {
					case 0:
						arc(0, gridSize / 2, gridSize - offset, gridSize - offset, PI / 2, -PI / 2);
						break;
					case 1:
						arc(gridSize, gridSize / 2, gridSize - offset, gridSize - offset, -PI / 2, PI / 2);
						break;
					case 2:
						line(0, offset, gridSize, offset);
						break;
					case 3:
						line(0, gridSize - offset, gridSize, gridSize - offset);
						break;
					case 4:
						line(0, gridSize / 2 - gridSize / 16 + offset, gridSize, gridSize / 2 - gridSize / 16 + offset);
						line(gridSize / 2 - gridSize / 16 + offset, 0, gridSize / 2 - gridSize / 16 + offset, gridSize);
						break;
					case 5:
						bezier(0, offset, gridSize / 2, offset, gridSize / 2, gridSize - offset, gridSize, gridSize - offset);
						break;
					case 6:
						bezier(gridSize, offset, gridSize / 2, offset, gridSize / 2, gridSize - offset, 0, gridSize - offset);
						break;
					case 7:
						bezier(0, gridSize / 2 - gridSize / 16 + offset, gridSize / 2, gridSize / 2 - gridSize / 16 + offset, gridSize / 2, gridSize - offset, gridSize, gridSize - offset);
						break;
					case 8:
						bezier(gridSize, gridSize / 2 - gridSize / 16 + offset, gridSize / 2, gridSize / 2 - gridSize / 16 + offset, gridSize / 2, gridSize - offset, 0, gridSize - offset);
						break;
					case 9:
						arc(gridSize / 2, gridSize - offset, gridSize, gridSize, -PI / 2, 0);
						break;
					case 10:
						arc(gridSize / 2, gridSize - offset, gridSize, gridSize, PI, -PI / 2);
						break;
				}
			}

			// 小符號
			stroke(symbolColor);
			strokeWeight(4);
			strokeCap(SQUARE);
			if (random() < 0.2) {

				line(gridSize / 16, gridSize / 16, gridSize / 16, gridSize / 4);
			}
			if (random() < 0.1) {

				line(gridSize / 16, gridSize / 16, gridSize / 4, gridSize / 16);
			}
			if (random() < 0.1) {

				line(gridSize - gridSize / 16, gridSize / 16, gridSize - gridSize / 16, gridSize / 4);
			}
			if (random() < 0.2) {

				line(gridSize - gridSize / 16, gridSize / 16, gridSize * 3 / 4, gridSize / 16);
			}
			if (random() < 0.1) {

				ellipse(gridSize / 16, gridSize * 3 / 4, gridSize / 32, gridSize / 32);
			}
			if (random() < 0.2) {

				ellipse(gridSize - gridSize / 16, gridSize * 3 / 4, gridSize / 32, gridSize / 32);
			}
			pop();
		}
	}
}

function keyPressed() {
	if (key == ' ') {

		paused = !paused;
		if (paused) {

			noLoop();
		} else {

			loop();
		}
	}

	if (key == 's' || key == 'S') {

		save("The_(Dis)Ordered_Score.png");
	}
}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}