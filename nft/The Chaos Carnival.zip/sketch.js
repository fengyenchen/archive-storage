
let targetCanvasWidth = 600;
let targetCanvasHeight = 600;
let deviceRatio = 1;

function SetupCanvasScale() {
    let originalDensity = pixelDensity();

    if (windowWidth > targetCanvasWidth) {
        deviceRatio = (windowWidth / targetCanvasWidth);
    } else {
        deviceRatio = originalDensity;
    }

    deviceRatio = max(deviceRatio, 1);
    pixelDensity(deviceRatio);
}

let c;
let frameCountThreshold = 1680;
let xx=[];
let mode=[];
let lyr1;
let texture;
let count = 35;


let bodyCount = 3; 
let earsCount = 3;
let eyesCount = 3;
let bgDecoCount = 3;
let decoCount = 3;

// 存資料
let colorFactor;
let bgColor1, bgColor2;
let bgDecoId;
let bodyId, earsId, eyesId;
let bodyFactor1;
let bodyFactor2;
let mainCoior;
let decoId;

// 存所有
let bgDeco = [];
let body = [];
let ears = [];
let eyes = [];
let deco = [];
let mainColors = [
  "#FFF9E3",
  "#FFE0B2",
  "#E0E0E0",
  "#F5F5F5",
  "#D7CCC8",
  "#E8D9E5",
  "#E4E9F1",
  "#FFF3E0"
];

function preload(){
	texture = loadImage("4.jpg");

	for (let i=0; i<bodyCount; i++){
		body[i] = loadImage("body"+(i+1)+".png");
	}
	for (let i=0; i<earsCount; i++){
		ears[i] = loadImage("ears"+(i+1)+".png");
	}
	for (let i=0; i<eyesCount; i++){
		eyes[i] = loadImage("eyes"+(i+1)+".png");
	}
	for (let i=0; i<decoCount; i++){
		deco[i] = loadImage("deco"+(i+1)+".png");
	}
}

async function setup() {
    createCanvas(targetCanvasWidth, targetCanvasHeight);
    SetupCanvasScale();
    flex();


    c = random(360);

	lyr1 = createGraphics(600,600);

	for (let i=0;i<count;i++){
		mode[i] = i%4;
		xx[i] = random(width/7)+(i%7)*(width/7);
	}

	init(1);

	frameRate(120);
}

function draw() {
	if (frameCount<frameCountThreshold-20){
		lyr1.drawingContext.shadowColor = color(30,30);
		lyr1.drawingContext.shadowOffsetY = 3;
		lyr1.drawingContext.shadowOffsetX = 6;
		lyr1.drawingContext.shadowBlur = 10;
		
		lyr1.push();
		lyr1.translate(width/2,height/2);
		
		lyr1.push();
		lyr1.rotate(-PI/2+frameCount/30);
		lyr1.translate(frameCount/5+random(25),frameCount/5+random(10));
		lyr1.colorMode(RGB);
		lyr1.stroke(250);
		lyr1.strokeWeight(random(2));
		lyr1.line(random(-10,10),random(-10,10),random(-10,10),-random(80,120));
		lyr1.line(random(-10,10),random(-10,10),random(-10,10),-random(80,120));
		lyr1.line(random(-10,10),random(-10,10),random(-10,10),-random(80,120));
		lyr1.line(random(-10,10),random(-10,10),random(-10,10),-random(80,120));
		lyr1.rotate(PI/2+frameCount/random(20,30));
		lyr1.circle(random(80,120),-random(80,120),random(1,5));
		lyr1.pop();
		
		lyr1.push();
		lyr1.rotate(frameCount/30);
		lyr1.translate(frameCount/5+random(25),frameCount/5+random(10));
		lyr1.colorMode(HSB);
		lyr1.noStroke();
		lyr1.fill(c,80,frameCount/20);
		lyr1.quad(random(40,80),random(40,80),random(40,80),-random(40,80),-random(40,80),-random(40,80),-random(40,80),random(40,80));
		lyr1.fill(c,80,frameCount/20+20);
		lyr1.triangle(0,-random(125,180),random(40,65),random(40,65),-random(40,65),random(40,65));
		lyr1.pop();
		
		lyr1.pop();
		image(lyr1,0,0);
	}else if (frameCount<frameCountThreshold){
		lyr1.push();
		lyr1.blendMode(MULTIPLY);
		lyr1.tint(255,8);
		lyr1.image(texture,-10,-10,width+20,height+20);
		lyr1.pop();
		image(lyr1,0,0);
	}else if (frameCount<frameCountThreshold+600){
		image(lyr1,0,0);
		for (let i=0;i<count;i++){
			stroke(250);
			strokeWeight(random(1,3));
			line(xx[i],-20,xx[i],easeOutBounce(map(frameCount,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20);
			if (mode[i]==0){
				drawGost(xx[i],easeOutBounce(map(frameCount,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20, i);
			}else if(mode[i]==1){
				drawEye(xx[i],easeOutBounce(map(frameCount,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20, i);
			}else{
				strokeWeight(mode[i]*2);
				line(xx[i],-35,xx[i],easeOutBounce(map(frameCount,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-35);
				strokeWeight(mode[i]*3);
				line(xx[i],-55,xx[i],easeOutBounce(map(frameCount,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-55);
			}
		}
	}
	
	if (frameCount>frameCountThreshold+600){
		image(lyr1,0,0);
		for (let i=0;i<count;i++){
			stroke(250);
			strokeWeight(random(1,3));
			line(xx[i],-20,xx[i],easeOutBounce(map(frameCountThreshold+600,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20);
			if (mode[i]==0){
				drawGost(xx[i],easeOutBounce(map(frameCountThreshold+600,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20, i);
			}else if(mode[i]==1){
				drawEye(xx[i],easeOutBounce(map(frameCountThreshold+600,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-20, i);
			}else{
				strokeWeight(mode[i]*2);
				line(xx[i],-35,xx[i],easeOutBounce(map(frameCountThreshold+600,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-35);
				strokeWeight(mode[i]*3);
				line(xx[i],-55,xx[i],easeOutBounce(map(frameCountThreshold+600,frameCountThreshold-i*20,frameCountThreshold-i*20+600,0,1))*100-55);
			}
		}

		push();
		translate(width/2,height/2+60);
		rotate(sin(frameCount/50)/12);
		scale(abs(sin(frameCount/50))/20+1);
		if (frameCount<frameCountThreshold+680 && random()<0.6 ||
		   frameCount>frameCountThreshold+680){
			drawMonster(0,0,1.15);
		}
		pop();

		tint(255,20);
		image(lyr1,0,0);
	}
}

function drawGost(xx,yy,i){
	push();
	translate(xx,yy);
	translate(0,15);
	scale(map(pow(i+1,0.2),1,2,0.95,1.25));
	fill(250);
	noStroke();
	circle(0,0,30);
	beginShape();
	vertex(0,10);
	bezierVertex(0,10,-5-noise(1000)*10,22+noise(1000)*10,-15,55);
	bezierVertex(-15,55,noise(1000)*20,55+noise(1000)*20,15,55);
	bezierVertex(15,55,5+noise(1000)*10,22+noise(1000)*10,0,10);
	vertex(0,10);
	endShape();
	pop();
}

function drawEye(xx,yy,i){
	push();
	translate(xx,yy);
	translate(0,10);
	scale(map(pow(i+1,0.2),1,2,0.65,1.05));
	fill(250);
	noStroke();
	circle(0,0,30);
	fill(c,100,90);
	circle(0,0,20);
	fill(30);
	circle(0,0,12);
	pop();
}

function easeOutBounce(x) {
	const n1 = 7.5625;
	const d1 = 2.75;
	
	if (x < 1 / d1) {
	    return n1 * x * x;
	} else if (x < 2 / d1) {
	    return n1 * (x -= 1.5 / d1) * x + 0.75;
	} else if (x < 2.5 / d1) {
	    return n1 * (x -= 2.25 / d1) * x + 0.9375;
	} else {
	    return n1 * (x -= 2.625 / d1) * x + 0.984375;
	}
}


function init(count){
	for (let i=0;i<count;i++){	
		bodyId = int(random(bodyCount));
		earsId = int(random(earsCount));
		eyesId = int(random(eyesCount));
		bodyFactor1 = random();
		bodyFactor2 = random();
	
		mainCoior = int(random(mainColors.length));
	
		decoId = int(random(decoCount));
	}
}

function drawMonster(xx,yy,size) {
	push();
	translate(xx,yy);
	scale(size);

	// 耳朵
	tint(color(mainColors[mainCoior])); 
	image(ears[earsId], -width/2, -height/2, width, height);
	
	// 身體
	tint(color(mainColors[mainCoior]));
	image(body[bodyId], -width/2, -height/2, width, height);
	if(bodyFactor1<0.3){
		image(body[(bodyId+1)%bodyCount], -width/2, -height/2, width, height);
	}
	if(bodyFactor2<0.1){
		image(body[(bodyId+2)%bodyCount], -width/2, -height/2, width, height);
	}
	
	// 眼睛
	noTint(); 
	image(eyes[eyesId], -width/2, -height/2, width, height);

	// 裝飾
	image(deco[decoId], -width/2, -height/2, width, height);

	pop();
}


function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}