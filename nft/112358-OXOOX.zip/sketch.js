// m0: palette (m0 < 0.25 : 黑灰紅, 0.25 <= m0 < 0.5 : 米灰藍, 0.5 <= m0 < 0.75 : 灰黑白, m0 >= 0.75 : 黑綠白)
// m1: noise factor
// m2: radius factor
// m3: mode (m3 < 0.33 : 方塊, 0.33 <= m3 < 0.66 : 文字, m3 >= 0.66 : 混和)
// m4: id (1 ~ 9989)

let targetCanvasWidth = 600;
let targetCanvasHeight = 600;
let deviceRatio = 1;

let margin = 35;
let grid = margin;
let mode;
let hasUnderline;
let hasDifferentTextStyle;
let id1, id2;

let palettes;
let activePalette;

let myFont;
let myFontNormal, myFontBold, myFontItalic, myFontBoldItalic;

function editRandom(from = 0, to = 1) {
    let diff = to - from;
    return from + randomFull() * diff;
}

function SetupCanvasScale() {
    let originalDensity = pixelDensity();

    if (windowWidth > targetCanvasWidth) {
        deviceRatio = (windowWidth / targetCanvasWidth);
    } else {
        deviceRatio = originalDensity;
    }

    deviceRatio = max(deviceRatio, 1);
    pixelDensity(deviceRatio * 1.5);
}

function windowResizedUser() {
    // do nothing, because p5.flex handles the resizing
}

function preload() {
    myFontNormal = loadFont('NotoSans_Condensed-Regular.ttf');
    myFontBold = loadFont('NotoSans_Condensed-Bold.ttf');
    myFontItalic = loadFont('NotoSans_Condensed-Italic.ttf');
    myFontBoldItalic = loadFont('NotoSans_Condensed-BoldItalic.ttf');
}

async function setup() {
    createCanvas(targetCanvasWidth, targetCanvasHeight);
    SetupCanvasScale();
    flex();
    noLoop();
}

async function draw() {
    // 固定 noise 的隨機種子
    noiseSeed(editRandom(0, 1000000));

    let noiseFactorX = lerp(50, 200, m1);
    let noiseFactorY = lerp(50, 200, m1);
    let radiusFactor1 = lerp(2, 8, m2);
    let radiusFactor2 = editRandom(2, 8);

    if (m3 < 0.33) {
        mode = 0; // 方塊
    } else if (m3 < 0.66) {
        mode = 1; // 文字
    } else {
        mode = 2; // 混和
    }

    hasUnderline = editRandom() < 0.5;
    hasDifferentTextStyle = editRandom() < 0.5;

    id1 = int(1 + m4 * 9998);
    id2 = int(9999 + editRandom(9999));

    palettes = [{
        bg: color(30, 30, 35),
        primary: color(230),
        accent: color(255, 80, 80),
        paper: color(45, 45, 50),
        text: color(255)
    }, // 黑灰紅
    {
        bg: color(245, 240, 225),
        primary: color(60),
        accent: color(40, 140, 240),
        paper: color(255, 252, 240),
        text: color(80)
    }, // 米灰藍
    {
        bg: color(100, 100, 100),
        primary: color(35),
        accent: color(240, 240, 240),
        paper: color(160, 160, 160),
        text: color(255)
    }, // 灰黑白
    {
        bg: color(20, 20, 20),
        primary: color(0, 255, 150),
        accent: color(240),
        paper: color(40, 40, 40),
        text: color(0, 255, 150)
    } // 黑綠白
    ];

    if (m0 < 0.25) {
        activePalette = palettes[0];
    } else if (m0 < 0.5) {
        activePalette = palettes[1];
    } else if (m0 < 0.75) {
        activePalette = palettes[2];
    } else {
        activePalette = palettes[3];
    }

    background(activePalette.bg);

    rectMode(CORNER);
    fill(activePalette.paper);
    noStroke();
    rect(margin, margin, width - margin * 2, height - margin * 2);

    let bgRectMode;
    if (m1 < 0.8 && m1 > 0.2) {
        bgRectMode = "allFillRect"
    } else if (m1 < 0.2) {
        bgRectMode = "allStrokeRect"
    } else {
        bgRectMode = "mixFillStrokeRect"
    }
    // 方塊
    for (let i = margin * 2; i < width - margin * 3; i += grid) {
        for (let j = margin * 2; j < height - margin * 3; j += grid) {
            if (noise(i / noiseFactorX, j / noiseFactorY) < 0.62 && noise(i / noiseFactorX, j / noiseFactorY) > 0.53) {
                if (bgRectMode == "allFillRect") {
                    fill(activePalette.accent, 180);
                    noStroke();
                } else if (bgRectMode == "allStrokeRect") {
                    stroke(activePalette.accent, 180);
                    strokeWeight(1.5);
                    noFill();
                } else if (bgRectMode == "mixFillStrokeRect") {
                    if (editRandom() < 0.5) {
                        fill(activePalette.accent, 180);
                        noStroke();
                    } else {
                        stroke(activePalette.accent, 180);
                        strokeWeight(1.5);
                        noFill();
                    }
                }
                rect(i, j, grid * 1.5, grid * 1.5, (grid * 1.5) / radiusFactor1);
                if (editRandom() < 0.3 && ((m1 < 0.35 && m1 > 0.1) || (m1 > 0.65 && m1 < 0.9))) {
                    stroke(activePalette.accent, 100);
                    strokeWeight(1);
                    noFill();
                    rect(i - grid * 0.1, j - grid * 0.1, grid * 1.7, grid * 1.7, (grid * 1.7) / radiusFactor1);
                }
            }
        }
    }

    // 細線
    for (let i = 0; i < width; i += (grid / 10)) {
        for (let j = 0; j < height; j += (grid / 10)) {
            if (noise(i / noiseFactorX, j / noiseFactorY) < 0.48 && noise(i / noiseFactorX, j / noiseFactorY) > 0.4789) {
                fill(activePalette.accent, 150);
                noStroke();
                rectMode(CENTER);
                rect(i, j, (grid / 10) * 0.5, height / 2, ((grid / 10) * 0.6) / radiusFactor1);
            }
        }
    }

    let currentNum = 1, lastNum = 0;
    let gap;

    // 主體
    for (let i = margin * 3.2; i < height - margin; i += gap * 1.3) {
        let txt = "";
        let underLine = "";
        for (let j = 0; j < currentNum; j++) {
            txt += currentNum;
            if (textWidth(txt) > width - margin * 2.5) {
                break;
            }
        }
        for (let k = 0; k < txt.length; k++) {
            underLine += "_";
        }

        gap = 40 / pow(currentNum, 0.25);

        if (mode == 0) {
            // 方塊主體
            fill(activePalette.primary, 252);
            noStroke();
            rectMode(CENTER);
            rect(width / 2, i - gap * 0.32, textWidth(txt) * 1.55, gap * 1.25, gap / radiusFactor2);
        }

        if (mode == 1) {
            // 文字主體
            textSize(gap);
            let tf;
            if (editRandom() < 0.3) {
                tf = myFontItalic;
                textFont(tf);
            } else if (editRandom() < 0.5) {
                tf = myFontNormal;
                textFont(tf);
            } else if (editRandom() < 0.8) {
                tf = myFontBold;
                textFont(tf);
            } else {
                tf = myFontBoldItalic;
                textFont(tf);
            }

            if (!hasDifferentTextStyle) {
                textFont(myFontNormal);
            }

            textAlign(CENTER);
            fill(activePalette.primary);
            noStroke();

            text(txt, width / 2, i);
            if (hasUnderline && editRandom() < 0.5) {
                textFont(tf);
                text(underLine, width / 2, i);
            }
        }

        // 方塊文字主體
        if (mode == 2) {
            fill(activePalette.primary, 252);
            noStroke();
            rectMode(CENTER);
            rect(width / 2, i - gap * 0.32, pow(textWidth(txt), 0.85) * 6, gap * 1.25, gap / radiusFactor2);

            fill(activePalette.bg);
            textAlign(CENTER);
            textSize(gap);
            textFont(myFontBold);
            text(txt, width / 2, i);
        }

        let temp = currentNum;
        currentNum += lastNum;
        lastNum = temp;
        if (currentNum > 1000) {
            break;
        }
    }

    // 頂部裝飾
    fill(activePalette.primary);
    noStroke();
    rectMode(CORNER);
    rect(margin, margin, width - margin * 2, 22);

    for (let i = 0; i < editRandom(2, 8); i++) {
        fill(activePalette.primary);
        rectMode(CENTER);
        if (editRandom() < 0.5) {
            rect(editRandom(margin + grid / 2, width / 2 - grid), margin + editRandom(28, 40), editRandom(3, 8));
        } else {
            rect(editRandom(width / 2 + grid, width - margin - grid / 2), margin + editRandom(28, 40), editRandom(3, 8));
        }
    }

    // 底部裝飾
    fill(activePalette.primary);
    noStroke();
    rectMode(CORNER);
    rect(margin, height - margin - 5, width - margin * 2, 5);
    rect(margin, height - margin - 9.5, width - margin * 2, 3);
    rect(margin, height - margin - 13, width - margin * 2, 1);

    // 外框
    noFill();
    stroke(activePalette.bg);
    strokeWeight(margin * 2);
    rectMode(CORNER);
    rect(0, 0, width, height);

    // 四角資訊文字
    fill(activePalette.text);
    noStroke();
    textFont(myFontNormal);
    textSize(12);

    textAlign(LEFT);
    text(id1 + " - " + id2, margin, margin / 1.3);

    textAlign(RIGHT);
    text(id1.toString(2) + " - " + id2.toString(2), width - margin, height - margin / 2);

    push();
    translate(width, 0);
    rotate(PI / 2);
    textAlign(LEFT);
    text("xxoxxoo", margin, margin / 1.3);
    pop();

    push();
    translate(0, height);
    rotate(-PI / 2);
    textAlign(LEFT);
    text("112358 / ...", margin, margin / 1.3);
    pop();


    triggerPreview();
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function keyPressed() {
    if (key == "s" || key == "S") {
        save("112358-OXOOX.png")
    }
}