let cs;
let layer;
let radiusMax;
let radiusList = [];
let directionList = [];
let colors = [];
let colorSelected;
let hasOffset;
let hasRotate;
let rotateFactor;
let offsetDir;
let hasDiff;
let diffMode;

function setup() {
	cs = min(windowWidth, windowHeight);
	createCanvas(cs, cs);
	noLoop();
	setSeeds();

	colors = [{
			bg: color(237, 232, 222),
			p: "#0a0a0a"
		},
		{
			bg: "#0a0a0a",
			p: color(237, 232, 222)
		}
	];

	colorSelected = int(random(colors.length));
	background(colors[colorSelected].bg);

	layer = int(random(3, 50));
	radiusList[0] = cs * 0.5 * pow(2, 0.5);
	radiusMax = cs * random(0.42, 0.48);

	for (let i = 1; i < layer; i++) {
		radiusList[i] = radiusMax - i * (radiusMax / layer) * random(0.8, 1);
		directionList[i] = random() < 0.25 ? 0 : 1;
	}
	radiusList[layer] = cs / 500;

	hasOffset = random() < 0.5;
	hasRotate = random() < 0.5;
	rotateFactor = random([0.25, 0.5, 1, 2]);
	offsetDir = [random([0, 1]), random([-1, 1])];

	hasDiff = random() < 0.5;
	diffMode = random([1, 2, 3, 4]);
	if (offsetDir[0] == 0) {
		diffMode = random([1, 2, 3, 4]);
	}
	if (rotateFactor == 0.25) {
		diffMode = random([5, 6, 7, 8]);
	}

	blendMode(BLEND);

	push();
	translate(width / 2, height / 2);
	for (let i = 1; i < layer; i++) {
		push();

		let offset = hasOffset ? i * cs * 0.005 * offsetDir[1] : 0;
		if (hasRotate) {
			rotate(i * PI * rotateFactor);
		}

		if (offsetDir[0] == 0) {
			translate(0, offset)
		} else {
			translate(offset, 0)
		}

		strokeWeight(cs / 500);
		stroke(colors[colorSelected].p);
		fill(colors[colorSelected].bg);
		circle(0, 0, radiusList[i] * 2);

		strokeWeight(cs / 450);
		stroke(colors[colorSelected].p);
		let times = pow(radiusList[i], 0.5) * random(700, 1400);
		let p = random(3, 7);

		if (directionList[i] == 0) {
			for (let j = 0; j < times; j++) {
				let ang = random(PI * 2);
				let r = radiusList[i] + (radiusList[i - 1] - radiusList[i]) * pow(random(), p);
				point(r * cos(ang), r * sin(ang));
			}
		} else {
			for (let j = 0; j < times; j++) {
				let ang = random(PI * 2);
				let r = radiusList[i] - (radiusList[i] - radiusList[i + 1]) * pow(random(), p);
				point(r * cos(ang), r * sin(ang));
			}
		}
		pop();
	}

	pop();

	if (hasDiff) {
		blendMode(DIFFERENCE);
		noStroke();
		fill(255);
		if (diffMode == 1) {
			rect(0, 0, width, height / 2);
		} else if (diffMode == 2) {
			rect(0, height / 2, width, height / 2);
		} else if (diffMode == 3) {
			rect(0, 0, width / 2, height);
		} else if (diffMode == 4) {
			rect(width / 2, 0, width / 2, height);
		} else if (diffMode == 5) {
			triangle(0, 0, width, 0, 0, height);
		} else if (diffMode == 6) {
			triangle(width, 0, 0, height, width, height);
		} else if (diffMode == 7) {
			triangle(0, 0, width, 0, width, height);
		} else if (diffMode == 8) {
			triangle(0, 0, 0, height, width, height);
		}
	}

	radiusList = [];
	directionList = [];
}

function draw() {

	triggerPreview();
}

function keyPressed() {
	if (key == "s" || key == "S") {
		save("Void.png");
	}
}

function windowResized() {
	setSeeds();
	cs = min(windowHeight, windowWidth);
	resizeCanvas(cs, cs);
}